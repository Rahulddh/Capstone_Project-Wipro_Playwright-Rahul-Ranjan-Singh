class FrontPanelLoader{cookieKeys={};urlToFetchData="";containerId="";data={};constructor(cookieKeys,urlToFetchData,containerId){this.cookieKeys=cookieKeys;this.urlToFetchData=urlToFetchData;this.containerId=containerId;}
init(){if(!this.isAuthorized(this.cookieKeys)){return;}
fetch(this.urlToFetchData,{method:"POST",headers:{"X-Requested-With":"XMLHttpRequest",},body:new URLSearchParams({url:window.location.href})}).then(response=>{if(response.ok){return response.json();}else{console.warn("GET request failed",response);}}).then(data=>{if(!data||!data.panel){return;}
this.data=data;const wrapper=document.getElementById(this.containerId);wrapper.innerHTML=this.data.panel;FrontPanelLib.parse(wrapper);});}
isAuthorized(cookieKeys){let authorised=false;for(const cookieKey of cookieKeys){authorised=authorised||FrontPanelLib.getCookie(cookieKey)!==null;}
return authorised;}}
class FrontPanelLib{static#NODE_TO_REPLACE=['SCRIPT','STYLE'];static parse(node){if(this.shouldReplaceNode(node)===true){node.parentNode.replaceChild(this.nodeClone(node),node);}
else{let i=-1,children=node.childNodes;while(++i<children.length){this.parse(children[i]);}}
return node;}
static getCookie(name){const match=document.cookie.match(new RegExp('(^| )'+name+'=([^;]+)'));if(match)return match[2];return null;}
static nodeClone(node){const newNode=document.createElement(node.tagName.toLowerCase());newNode.innerHTML=node.innerHTML;let i=-1,attrs=node.attributes,attr;while(++i<attrs.length){newNode.setAttribute((attr=attrs[i]).name,attr.value);}
return newNode;}
static shouldReplaceNode(node){return this.#NODE_TO_REPLACE.includes(node.tagName);}}